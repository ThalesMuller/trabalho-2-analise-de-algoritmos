"use strict";
exports.__esModule = true;
exports.PARTICLE_QUANTITY = 10;
exports.MAX_LOOP_ITERACTIONS = 5000;
exports.COGNITIVE_IMPORTANCE = 1;
exports.SOCIAL_IMPORTANCE = 2;
